## ArgoCD Notifications Chart

This is a **community maintained** chart. It installs the [argocd-notifications](https://github.com/argoproj-labs/argocd-notifications) application. This application comes packaged with:
- Notifications Controller Deployment
- Notifications Controller ConfigMap
- Notifications Controller Secret
- Service Account
- Roles
- Role Bindings
