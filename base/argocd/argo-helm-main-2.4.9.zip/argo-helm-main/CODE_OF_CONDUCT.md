# Code of Conduct

We adhere to the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/main/code-of-conduct.md).  Please reference the link for details.

## TL;DR (too long didn't read)

Be kind

Your participation is at the discression of the maintainers of this project.
