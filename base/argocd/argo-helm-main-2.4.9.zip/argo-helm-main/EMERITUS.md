# Emeritus Approvers

These are the people who have been approvers in the past, and have since retired from the role.

We thank them for their service to the project.

| Emeritus | GitHub ID |
| -------- | --------- |
| Oliver Bähler | [oliverbaehler](https://github.com/oliverbaehler) |
| Stefan Sedich | [stefansedich](https://github.com/stefansedich) |
| Pablo Osinaga | [paguos](https://github.com/paguos) |
| Yann Soubeyrand | [yann-soubeyrand](https://github.com/yann-soubeyrand) |
| David J. M. Karlsen | [davidkarlsen](https://github.com/davidkarlsen) |
| John Behling | [jbehling](https://github.com/jbehling) |
