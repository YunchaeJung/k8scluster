module.exports = {
    platform: 'github',
    gitAuthor: 'renovate[bot] <renovate[bot]@users.noreply.github.com>',
    autodiscover: false,
    allowPostUpgradeCommandTemplating: true,
    allowedPostUpgradeCommands: [".*"],
  };
